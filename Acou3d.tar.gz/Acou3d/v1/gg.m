%------------------------------------------------------------
if(1)
  chgeo = 'cube';
  chfld = 'zdir';
  chchk = 'z+';
  K = 2;
  NPW = 0;
  
  %--------
  binstr = sprintf('%s_%d_%d_vert',chgeo,K,NPW);
  fid = fopen(binstr,'r');
  string = {'vector',{'Point3'}};
  vert = deserialize(fid, string);
  fclose(fid);
  
  binstr = sprintf('%s_%d_%d_face',chgeo,K,NPW);
  fid = fopen(binstr,'r');
  string = {'vector',{'Index3'}};
  face = deserialize(fid, string);
  fclose(fid);
  
  vs = zeros(3,numel(vert));
  for a=1:numel(vert)
    vs(:,a) = vert{a};
  end
  fs = zeros(3,numel(face));
  for a=1:numel(face)
    fs(:,a) = face{a};
  end
  %trimesh(fs'+1,vs(1,:),vs(2,:),vs(3,:));
  
  %----------
  if(strcmp(chfld,'zdir')==1)
    dir = [0,0,-1];
    tmp = vs(1,:)*dir(1) + vs(2,:)*dir(2) + vs(3,:)*dir(3);
    bs = - exp(2*pi*i*tmp); %neg
  else
    error('wrong');
  end
  tmp = cell(numel(vert),1);
  for idx=1:numel(vert)
    tmp{idx} = bs(idx);
  end
  binstr = sprintf('%s_%d_%d_bcn',chgeo,K,NPW);
  fid = fopen(binstr,'w');
  string = {'vector',{'cpx'}};
  serialize(fid, tmp, string);
  fclose(fid);
  
  trimesh(fs'+1,vs(1,:),vs(2,:),vs(3,:),real(bs));
  
  
  %----------
  if(strcmp(chchk,'z+')==1) 
    step=1/5;
    R = K/2;
    tmp = [-R+step/2:step:R];
    [xs,ys] = ndgrid(tmp);
    zs = R-step/2 * ones(size(xs));
    xs = xs(:);
    ys = ys(:);
    zs = zs(:);
    ps = [xs';ys';zs'];
  elseif(strcmp(chchk,'z-')==1)
    error('wrong');
  else
    error('wrong');
  end
  NC = size(ps,2);
  tmp = cell(NC,1);
  for idx=1:NC
    tmp{idx} = [ps(1,idx),ps(2,idx),ps(3,idx)];
  end
  binstr = sprintf('%s_%d_%d_chk',chgeo,K,NPW);
  fid = fopen(binstr,'w');
  string = {'vector',{'Point3'}};
  serialize(fid,tmp,string);
  fclose(fid);
  
end

%------------------------------------------------------------

