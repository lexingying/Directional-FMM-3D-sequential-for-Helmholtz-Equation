#include "acou3d.hpp"
#include "serialize.hpp"
#include "trmesh.hpp"

using std::cerr;

//-----------------------------------
Acou3d::Acou3d(const string& p): ComObject(p), _wave(p+"_wave")
{
}

//-----------------------------------
Acou3d::~Acou3d()
{
}

//-----------------------------------
int Acou3d::setup(vector<Point3>& vertvec, vector<Index3>& facevec,
		  Point3 ctr, int accu, Kernel3d knlbie)
{
  _vertvec = vertvec;
  _facevec = facevec;
  _ctr = ctr;
  _accu = accu;
  _knlbie = knlbie; cerr<<"type "<<_knlbie.type()<<endl;
  //1. compute _diavec
  TrMesh trmesh("");
  iC( trmesh.setup(vertvec, facevec) );
  iC( trmesh.compute_interior(_diavec) );
  for(int k=0; k<_diavec.size(); k++) {
    _diavec[k] /= (4*M_PI);
  }
  iC( trmesh.compute_area(_arevec) );
  //cerr<<"DIA"<<endl;  for(int k=0; k<_diavec.size(); k++) cerr<<_diavec[k]<<" ";  cerr<<endl;
  //cerr<<"ARE"<<endl;  for(int k=0; k<_arevec.size(); k++) cerr<<_arevec[k]<<" ";  cerr<<endl;
  //
  //2. load the quad weights
  vector<int> all(1,1);
  ifstream gin("gauwgts.bin");
  iC( deserialize(_gauwgts, gin, all) );
  cerr<<"gauwgts size "<<_gauwgts.size()<<endl;
  ifstream lin("sigwgts.bin");
  iC( deserialize(_sigwgts, lin, all) );
  cerr<<"sigwgts size "<<_sigwgts.size()<<endl;
  //
  return 0;
}

//-----------------------------------
int Acou3d::solve(vector<cpx>& rhs, vector<cpx>& den)
{
  //1. create fmm
  iA(_gauwgts.find(5)!=_gauwgts.end());  iA(_sigwgts.find(5)!=_sigwgts.end());
  DblNumMat& gauwgt = _gauwgts[5]; cerr<<gauwgt.m()<<endl;
  DblNumMat& sigwgt = _sigwgts[5]; cerr<<sigwgt.m()<<endl;
  int NF = _facevec.size();
  int NV = _vertvec.size();
  //
  //2. setup
  // sample points to get the pvec nvec
  int numgau = gauwgt.m();
  _posvec.clear();
  _norvec.clear();
  for(int fi=0; fi<_facevec.size(); fi++) {
    Point3 pos0 = _vertvec[ _facevec[fi](0) ];
    Point3 pos1 = _vertvec[ _facevec[fi](1) ];
    Point3 pos2 = _vertvec[ _facevec[fi](2) ];
    double are = _arevec[fi];
    Point3 nor = cross(pos1-pos0, pos2-pos0);    nor = nor/nor.l2();
    //cerr<<nor<<" "<<(pos0+pos1+pos2)/3.0<<endl;
    for(int gi=0; gi<numgau; gi++) {
      double loc0 = gauwgt(gi,0);
      double loc1 = gauwgt(gi,1);
      double loc2 = gauwgt(gi,2);
      double wgt  = gauwgt(gi,3);
      _posvec.push_back( loc0*pos0+loc1*pos1+loc2*pos2 );
      _norvec.push_back( nor );
    }
  }
  for(int vi=0; vi<_vertvec.size(); vi++) {
    _posvec.push_back( _vertvec[vi] );
    _norvec.push_back( _vertvec[vi] ); //dummy
  }
  iA( _posvec.size()==NF*numgau+NV );
  iC( _wave.setup(_posvec, _norvec, _ctr, _accu, _knlbie) );
  //3. call gmres
  double tol;
  switch(_accu) {
  case 1:
    tol = 1e-3; break;
  case 2:
    tol = 1e-5; break;
  case 3:
    tol = 1e-7; break;
  }
  cerr<<"tol "<<tol<<endl;
  //
  int N = NV;
  Mat mat;  iC( MatCreateShell(PETSC_COMM_SELF, N, N, N, N, (void*)this, &mat) );
  iC( MatShellSetOperation(mat, MATOP_MULT, (void(*)(void))Acou3d::mmultWrapper) );
  //
  KSP ksp;  iC( KSPCreate(PETSC_COMM_SELF, &ksp) );
  iC( KSPSetOperators(ksp, mat, mat, DIFFERENT_NONZERO_PATTERN) );
  iC( KSPSetType(ksp, KSPGMRES) );
  iC( KSPSetTolerances(ksp, tol, PETSC_DEFAULT,PETSC_DEFAULT,PETSC_DEFAULT) );
  iC( KSPGMRESSetRestart(ksp, 100) );
  iC( KSPSetMonitor(ksp,KSPDefaultMonitor,PETSC_NULL,PETSC_NULL) );
  //allocate data
  Vec r;  iC( VecCreateSeqWithArray(PETSC_COMM_SELF, N, &(rhs[0]), &r) );
  Vec d;  iC( VecCreateSeq(PETSC_COMM_SELF, N, &d) );
  iC( KSPSolve(ksp, r, d) );
  int nit;  iC( KSPGetIterationNumber(ksp,&nit) );  cerr<<"nit "<<nit<<endl;
  //
  den.resize(N);
  cpx* darr;  iC( VecGetArray(d, &darr) );
  for(int k=0; k<N; k++)    den[k] = darr[k];
  iC( VecRestoreArray(d, &darr) );
  //
  iC( VecDestroy(r) ); r=NULL;
  iC( VecDestroy(d) ); d=NULL;
  iC( KSPDestroy(ksp) ); ksp=NULL;
  iC( MatDestroy(mat) ); mat=NULL;
  //checking
  /*
    vector<cpx> ot(N);
    vector<cpx> er(N);
    iC( mmult(den, ot) );
    for(int k=0; k<N; k++)    er[k] = ot[k]-rhs[k];
    { double sum = 0;  for(int k=0; k<er.size(); k++)    sum+=abs(er[k])*abs(er[k]);  cerr<<"ER ENE "<<sqrt(sum)<<endl; }
    { double sum = 0;  for(int k=0; k<rhs.size(); k++)    sum+=abs(rhs[k])*abs(rhs[k]);  cerr<<"RHS ENE "<<sqrt(sum)<<endl; }
  */
  return 0;
}


//-----------------------------------
int Acou3d::mmult(vector<cpx>& in, vector<cpx>& ot)
{
  iA(_gauwgts.find(5)!=_gauwgts.end());  iA(_sigwgts.find(5)!=_sigwgts.end());
  DblNumMat& gauwgt = _gauwgts[5];
  DblNumMat& sigwgt = _sigwgts[5];
  int numgau = gauwgt.m();
  int numsig = sigwgt.m();
  int NF = _facevec.size();
  int NV = _vertvec.size();
  //-------------
  if(       _knlbie.type()==KNL_HELM_DOUB) {
    //-----------------------------
    iA(0);
  } else if(_knlbie.type()==KNL_HELM_COMB) {
    //-----------------------------
    //1. scale wgt (gaussian)
    vector<cpx> tmp(NF*numgau + NV, cpx(0,0));
    int cnt = 0;
    for(int fi=0; fi<_facevec.size(); fi++) {
      double are = _arevec[fi];
      cpx den0 = in[ _facevec[fi](0) ];
      cpx den1 = in[ _facevec[fi](1) ];
      cpx den2 = in[ _facevec[fi](2) ];
      for(int gi=0; gi<numgau; gi++) {
	double loc0 = gauwgt(gi,0);
	double loc1 = gauwgt(gi,1);
	double loc2 = gauwgt(gi,2);
	double wgt  = gauwgt(gi,3);
	tmp[cnt] = (loc0*den0 + loc1*den1 + loc2*den2) * (are*wgt);
	cnt++;
      }
    }
    iA( cnt==NF*numgau );
    //2. call fmm
    vector<cpx> aux(NF*numgau + NV, cpx(0,0));
    time_t t0, t1;
    t0 = time(0);
    iC( _wave.eval(tmp,aux) );
    //double relerr;    iC( _wave.check(tmp,aux,4,relerr) );    cerr<<"relative error "<<relerr<<endl;
    t1 = time(0);  cout<<"wave eval used "<<difftime(t1,t0)<<"secs "<<endl;
    //3. angle
    for(int vi=0; vi<_vertvec.size(); vi++) {
      ot[vi] = _diavec[vi]*in[vi] + aux[cnt];
      cnt++;
    }
    iA( cnt==NF*numgau+NV );
    //3. remove nearby from ot
    t0 = time(0);
    for(int fi=0; fi<_facevec.size(); fi++) {
      //
      DblNumMat srcpos(3,numgau,false,(double*)(&(_posvec[fi*numgau])));
      DblNumMat srcnor(3,numgau,false,(double*)(&(_norvec[fi*numgau])));
      //
      vector<Point3> trgpostmp;
      trgpostmp.push_back( _vertvec[ _facevec[fi](0) ] );
      trgpostmp.push_back( _vertvec[ _facevec[fi](1) ] );
      trgpostmp.push_back( _vertvec[ _facevec[fi](2) ] );
      DblNumMat trgpos(3,3,false,(double*)(&(trgpostmp[0])));
      //
      CpxNumVec srcden(numgau,false,(cpx*)(&(tmp[fi*numgau])));
      //
      CpxNumVec trgval(3);
      //
      CpxNumMat mat;
      iC( _knlbie.kernel(trgpos, srcpos, srcnor, mat) );
      iC( zgemv(1.0, mat, srcden, 0.0, trgval) );
      //
      ot[ _facevec[fi](0) ] -= trgval(0);
      ot[ _facevec[fi](1) ] -= trgval(1);
      ot[ _facevec[fi](2) ] -= trgval(2);
    }
    //4. visit faces and add sing correction
    for(int fi=0; fi<_facevec.size(); fi++) {
      Point3 pos0 = _vertvec[ _facevec[fi](0) ];
      Point3 pos1 = _vertvec[ _facevec[fi](1) ];
      Point3 pos2 = _vertvec[ _facevec[fi](2) ];
      double are = _arevec[fi];
      Point3 nor = cross(pos1-pos0, pos2-pos0);    nor = nor/nor.l2();
      cpx den0 = in[ _facevec[fi](0) ];
      cpx den1 = in[ _facevec[fi](1) ];
      cpx den2 = in[ _facevec[fi](2) ];
      //
      //0
      {
	vector<Point3> srcpostmp;
	vector<Point3> srcnortmp;
	vector<Point3> trgpostmp;
	vector<cpx> srcdentmp;
	for(int li=0; li<numsig; li++) {
	  double loc0 = sigwgt(li,0);
	  double loc1 = sigwgt(li,1);
	  double loc2 = sigwgt(li,2);
	  double wgt  = sigwgt(li,3);
	  Point3 pos = loc0*pos0 + loc1*pos1 + loc2*pos2;
	  cpx    den = (loc0*den0 + loc1*den1 + loc2*den2)*(are*wgt);
	  srcpostmp.push_back( pos );
	  srcnortmp.push_back( nor );
	  srcdentmp.push_back( den );
	}
	trgpostmp.push_back( pos0 );
	DblNumMat srcpos(3,numsig,false,(double*)(&(srcpostmp[0])));
	DblNumMat srcnor(3,numsig,false,(double*)(&(srcnortmp[0])));
	DblNumMat trgpos(3,1,false,(double*)(&(trgpostmp[0])));
	CpxNumVec srcden(numsig,false,(cpx*)(&(srcdentmp[0])));
	CpxNumVec trgval(1);
	CpxNumMat mat;
	iC( _knlbie.kernel(trgpos, srcpos, srcnor, mat) );
	iC( zgemv(1.0, mat, srcden, 0.0, trgval) );
	ot[ _facevec[fi](0) ] += trgval(0);
      }
      //1
      {
	vector<Point3> srcpostmp;
	vector<Point3> srcnortmp;
	vector<Point3> trgpostmp;
	vector<cpx> srcdentmp;
	for(int li=0; li<numsig; li++) {
	  double loc0 = sigwgt(li,0);
	  double loc1 = sigwgt(li,1);
	  double loc2 = sigwgt(li,2);
	  double wgt  = sigwgt(li,3);
	  Point3 pos = loc0*pos1 + loc1*pos2 + loc2*pos0;
	  cpx    den = (loc0*den1 + loc1*den2 + loc2*den0)*(are*wgt);
	  srcpostmp.push_back( pos );
	  srcnortmp.push_back( nor );
	  srcdentmp.push_back( den );
	}
	trgpostmp.push_back( pos1 );
	DblNumMat srcpos(3,numsig,false,(double*)(&(srcpostmp[0])));
	DblNumMat srcnor(3,numsig,false,(double*)(&(srcnortmp[0])));
	DblNumMat trgpos(3,1,false,(double*)(&(trgpostmp[0])));
	CpxNumVec srcden(numsig,false,(cpx*)(&(srcdentmp[0])));
	CpxNumVec trgval(1);
	CpxNumMat mat;
	iC( _knlbie.kernel(trgpos, srcpos, srcnor, mat) );
	iC( zgemv(1.0, mat, srcden, 0.0, trgval) );
	ot[ _facevec[fi](1) ] += trgval(0);
      }
      //2
      {
	vector<Point3> srcpostmp;
	vector<Point3> srcnortmp;
	vector<Point3> trgpostmp;
	vector<cpx> srcdentmp;
	for(int li=0; li<numsig; li++) {
	  double loc0 = sigwgt(li,0);
	  double loc1 = sigwgt(li,1);
	  double loc2 = sigwgt(li,2);
	  double wgt  = sigwgt(li,3);
	  Point3 pos = loc0*pos2 + loc1*pos0 + loc2*pos1;
	  cpx    den = (loc0*den2 + loc1*den0 + loc2*den1)*(are*wgt);
	  srcpostmp.push_back( pos );
	  srcnortmp.push_back( nor );
	  srcdentmp.push_back( den );
	}
	trgpostmp.push_back( pos2 );
	DblNumMat srcpos(3,numsig,false,(double*)(&(srcpostmp[0])));
	DblNumMat srcnor(3,numsig,false,(double*)(&(srcnortmp[0])));
	DblNumMat trgpos(3,1,false,(double*)(&(trgpostmp[0])));
	CpxNumVec srcden(numsig,false,(cpx*)(&(srcdentmp[0])));
	CpxNumVec trgval(1);
	CpxNumMat mat;
	iC( _knlbie.kernel(trgpos, srcpos, srcnor, mat) );
	iC( zgemv(1.0, mat, srcden, 0.0, trgval) );
	ot[ _facevec[fi](2) ] += trgval(0);
      }
    }
    t1 = time(0);  cout<<"correction used "<<difftime(t1,t0)<<"secs "<<endl;
  }
  return 0;
}

//-----------------------------------
int Acou3d::mmultWrapper(Mat M, Vec in, Vec ot)
{
  Acou3d* ptr = NULL;
  iC( MatShellGetContext(M, (void**)&ptr) );
  int N = ptr->_vertvec.size();
  //
  vector<cpx> aa(N);
  cpx* inarr;  iC( VecGetArray(in, &inarr) );
  for(int k=0; k<N; k++)    aa[k] = inarr[k];
  iC( VecRestoreArray(in, &inarr) );
  //
  vector<cpx> bb(N,cpx(0,0));
  iC( ptr->mmult(aa, bb) );
  //
  cpx* otarr;  iC( VecGetArray(ot, &otarr) );
  for(int k=0; k<N; k++)    otarr[k] = bb[k];
  iC( VecRestoreArray(ot, &otarr) );
  //
  return 0;
}

//-----------------------------------
int Acou3d::eval(vector<Point3>& chk, vector<cpx>& den, vector<cpx>& val)
{
  DblNumMat& gauwgt = _gauwgts[5];
  //
  int numgau = gauwgt.m();
  int NF = _facevec.size();
  _posvec.clear();
  _norvec.clear();
  vector<cpx> denvec;
  vector<cpx> valvec;
  for(int fi=0; fi<_facevec.size(); fi++) {
    Point3 pos0 = _vertvec[ _facevec[fi](0) ];
    Point3 pos1 = _vertvec[ _facevec[fi](1) ];
    Point3 pos2 = _vertvec[ _facevec[fi](2) ];
    double are = _arevec[fi];
    Point3 nor = cross(pos1-pos0, pos2-pos0);    nor = nor/nor.l2();
    //
    cpx den0 = den[ _facevec[fi](0) ];
    cpx den1 = den[ _facevec[fi](1) ];
    cpx den2 = den[ _facevec[fi](2) ];
    //
    for(int gi=0; gi<numgau; gi++) {
      double loc0 = gauwgt(gi,0);
      double loc1 = gauwgt(gi,1);
      double loc2 = gauwgt(gi,2);
      double wgt  = gauwgt(gi,3);
      _posvec.push_back( loc0*pos0+loc1*pos1+loc2*pos2 );
      _norvec.push_back( nor );
      denvec.push_back( (loc0*den0+loc1*den1+loc2*den2)*(are*wgt) );
    }
  }
  for(int ci=0; ci<chk.size(); ci++) {
    _posvec.push_back( chk[ci] );
    _norvec.push_back( chk[ci] );
    denvec.push_back( cpx(0,0) );
  }
  iC( _wave.setup(_posvec,_norvec, _ctr, _accu, _knlbie) );
  valvec.resize(denvec.size(), cpx(0,0));
  iC( _wave.eval(denvec, valvec) );
  //double relerr;    iC( _wave.check(denvec,valvec,4,relerr) );    cerr<<"relative error "<<relerr<<endl;
  val.resize(chk.size());
  for(int ci=0; ci<chk.size(); ci++) {
    val[ci] = valvec[ numgau*NF + ci ];
  }
  return 0;
}


