#include "ccsurf.hpp"
#include "ccsurfvr.hpp"

using namespace std;

int optionsCreate(const char* optfile, map<string,string>& options)
{
  options.clear();
  ifstream fin(optfile);
  if(fin.good()==false) {
    cerr<<"wrong option file"<<endl;	 exit(1);
  }
  string name;  fin>>name;
  while(fin.good()) {
    char cont[100];	 fin.getline(cont, 99);
    options[name] = string(cont);
    fin>>name;
  }
  fin.close();
  return 0;
}

int main(int argc, char** argv)
{
  srand48( (long)time(NULL) );
  iA(argc==2);
  map<string,string> opts;
  optionsCreate(argv[1], opts);
  
  //1. ccsurf
  CCSurf ccsurf("ccsurf_");
  iC( ccsurf.setup(opts) );
  
  map<string,string>::iterator mi;
  mi = opts.find("-lvl"); iA(mi!=opts.end());
  int lvl;  { istringstream ss((*mi).second);  ss>>lvl; }
  for(int i=0; i<lvl; i++) {	 iC( ccsurf.subdivide(i) );  }
  
  CCSurfVr ccsurfvr(&argc, argv, &ccsurf, lvl);
  glutMainLoop();
  
  return 0;
}
