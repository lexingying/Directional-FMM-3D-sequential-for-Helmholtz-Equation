if(1)
  chgeo = 'tori';
  chfld = 'xdir';
  
  K = 16;
  NPW = 10;
  
  binstr = sprintf('%s_%d_%d_vert',chgeo,K,NPW);
  fid = fopen(binstr,'r');
  string = {'vector',{'Point3'}};
  vert = deserialize(fid, string);
  fclose(fid);
  
  binstr = sprintf('%s_%d_%d_face',chgeo,K,NPW);
  fid = fopen(binstr,'r');
  string = {'vector',{'Index3'}};
  face = deserialize(fid, string);
  fclose(fid);
  
  vs = zeros(3,numel(vert));
  for a=1:numel(vert)
    vs(:,a) = vert{a};
  end
  fs = zeros(3,numel(face));
  for a=1:numel(face)
    fs(:,a) = face{a};
  end

  %trisurf(fs'+1,vs(1,:),vs(2,:),vs(3,:));
  trimesh(fs'+1,vs(1,:),vs(2,:),vs(3,:));
  
  
end
