#include "ccsurf.hpp"
#include "ccsurfvr.hpp"

using namespace std;

int optionsCreate(int argc, char** argv, map<string,string>& options)
{
  options.clear();
  for(int k=1; k<argc; k=k+2) {
    options[ string(argv[k]) ] = string(argv[k+1]);
  }
  return 0;
}

int main(int argc, char** argv)
{
  srand48( (long)time(NULL) );
  map<string,string> opts;
  optionsCreate(argc, argv, opts);
  
  map<string,string>::iterator mi;
  //0. gpmesh
  mi = opts.find("-meshfile"); assert(mi!=opts.end());
  char meshfile[100];  {istringstream ss((*mi).second);  ss>>meshfile;}
  GpMesh gpmesh("gpmesh_");
  iC( gpmesh.setup(meshfile) );
  //1. ccsurf
  CCSurf ccsurf("ccsurf_");
  iC( ccsurf.setup(gpmesh) );
  //2. subdivide
  mi = opts.find("-lvl"); iA(mi!=opts.end());
  int lvl;  { istringstream ss((*mi).second);  ss>>lvl; }
  for(int i=0; i<lvl; i++) {	 iC( ccsurf.subdivide(i) );  }
  //3. view
  CCSurfVr ccsurfvr(&argc, argv, &ccsurf, lvl);
  glutMainLoop();
  return 0;
}
