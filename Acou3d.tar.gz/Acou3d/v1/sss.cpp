#include "wave3d.hpp"
//#include "serialize.hpp"

using namespace std;

int main()
{
  int kt=1, ct=0;
  int accu=1;
  int N=1000;
  double K=16.0;
  Kernel3d kernel(kt);
  Wave3d wave("");
  vector<Point3> loc, nor;
  vector<cpx> den(N);
  vector<cpx> val(N, cpx(0,0)); 
  Point3 ctr(0.0,0.0,0.0);
  Point3 tmploc, tmpnor;
  int numchk=100;
  double relerr;
  // points in square
  for(int i=0; i<N; i++)
  {
    double r = K/2.0*0.8;
    double theta = M_PI*drand48();
    double phi = 2*M_PI*drand48();
    tmploc[0]=r*sin(theta)*cos(phi);
    tmploc[1]=r*sin(theta)*sin(phi);
    tmploc[2]=r*cos(theta);
    loc.push_back(tmploc);
    tmpnor = tmploc/tmploc.l2();
    nor.push_back(tmpnor);
  }
  for(int i=0; i<N; i++)
  {
    den[i]=cpx(drand48(),drand48());
    //cout<<"density value "<<den(i,0)<<" "<<den(i,1)<<" "<<den(i,2)<<endl;
  }
  iC(wave.setup(loc,nor,ctr,accu,kernel));
  iC(wave.eval(den,val));
  iC(wave.check(den,val,numchk,relerr));
  cout<<"relative error "<<relerr<<endl;
  return 0;
}
