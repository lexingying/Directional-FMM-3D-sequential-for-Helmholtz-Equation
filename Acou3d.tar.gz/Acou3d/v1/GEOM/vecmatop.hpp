#ifndef _VECMATOP_HPP_
#define _VECMATOP_HPP_

#include "nummat.hpp"

//--------------------------------------------------
int dgemm(double alpha, const DblNumMat& A, const DblNumMat& B, double beta, DblNumMat& C);
int dgemm(int m, int n, int k, double alpha, double* A, double* B, double beta, double* C);

int dgemv(double alpha, const DblNumMat& A, const DblNumVec& X, double beta, DblNumVec& Y);
int dgemv(int m, int n, double alpha, double* A, double* X, double beta, double* Y);

//--------------------------------------------------
int zgemm(cpx alpha, const CpxNumMat& A, const CpxNumMat& B, cpx beta, CpxNumMat& C);
int zgemm(int m, int n, int k, cpx alpha, cpx* A, cpx* B, cpx beta, cpx* C);

int zgemv(cpx alpha, const CpxNumMat& A, const CpxNumVec& X, cpx beta, CpxNumVec& Y);
int zgemv(int m, int n, cpx alpha, cpx* A, cpx* X, cpx beta, cpx* Y);

//--------------------------------------------------
// interpolation, etc.
//evaluation flags
enum {  EVFLAG_VL = 1,  EVFLAG_FD = 2,  EVFLAG_SD = 4 };
//domain flag
enum {  DMFLAG_PERIOD = 0,  DMFLAG_CLOSED = 1 };

// cubic spline interpolation
int spev1d( int evflag, int dmflag, int dof, double* M, int n,   double e,   int i,   double u,   double* res);
int spev2d( int evflag, int dmflag, int dof, double* M, int* mn, double* ef, int* ij, double* uv, double* res);
int spcoef( int evflag, double u, double* us);
// cubic lagrangian interpolation
int lagev1d(int evflag, int pdflag, int dof, double* M, int n,   double e,   int i,   double u,   double* res);
int lagev2d(int evflag, int pdflag, int dof, double* M, int* mn, double* ef, int* ij, double* uv, double* res);
int lagev3d(int evflag, int pdflag, int dof, double* M, int* mno, double* efg, int* ijk, double* uvw, double* res);
int lagcoef(int evflag, double u, double* us);




#endif
