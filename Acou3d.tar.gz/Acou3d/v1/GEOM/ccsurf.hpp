#ifndef _CCSURF_HPP_
#define _CCSURF_HPP_

#include "gpmesh.hpp"
#include "nummat.hpp"
#include "ccsubmatlib.hpp"

//-------------------------------------------------
template <class F>
class CCRect {
public:
  int _m, _n;
  F* _data;
public:
  CCRect(int m=0, int n=0): _m(m), _n(n) {
    _data = new F[(_m+2)*(_n+2)]; assert( _data!=NULL );
  }
  CCRect(const CCRect& C): _m(C._m), _n(C._n) {
    _data = new F[(_m+2)*(_n+2)]; assert( _data!=NULL );
    memcpy( _data, C._data, (_m+2)*(_n+2)*sizeof(F) );
  }
  ~CCRect() {
    delete[] _data; _data = NULL;
  }
  CCRect& operator=(const CCRect& C) {
    delete[] _data; _data = NULL;
    _m = C._m; _n=C._n;
    _data = new F[(_m+2)*(_n+2)]; assert( _data!=NULL );
    memcpy( _data, C._data, (_m+2)*(_n+2)*sizeof(F) );
    return *this;
  }
  void resize(int m, int n)  {
    if(_m!=m || _n!=n) {
      delete[] _data; _data = NULL;
      _m = m; _n = n;
      _data = new F[(_m+2)*(_n+2)]; assert( _data!=NULL );
    }
  }
  const F& operator()(int i, int j) const  {
    assert( i>=-1 && i<_m+1 && j>=-1 && j<_n+1 );
    return _data[(i+1)+(j+1)*(_m+2)];
  }
  F& operator()(int i, int j)  {
    assert( i>=-1 && i<_m+1 && j>=-1 && j<_n+1 );
    return _data[(i+1)+(j+1)*(_m+2)];
  }
  int m() const { return _m; }
  int n() const { return _n; }
  F* data() const { return _data; }
};

//-------------------------------------------------
//subdivision surface
class CCSurf: public ComObject {
public:
  enum { EVAL_VL=1, EVAL_FD=2, EVAL_SD=4 };  //enum { MAXLEVELNUM=7 };
  typedef pair<int,int> intpair;
  typedef vector< CCRect<Point3> > DataLevel; //vector of faces
public:
  GpMesh _gpmesh;  //int _inlvl; // input level
  vector<DataLevel> _posvec; //vector of levels
public:
  CCSurf(const string& p): ComObject(p), _gpmesh(p) {;}
  ~CCSurf() {;}
  GpMesh& gpmesh() { return _gpmesh; }
  vector<DataLevel>& posvec() { return _posvec; }
  //
  int setup(GpMesh& gpmesh);
  //int setup(map<string,string>& opts);
  int eval(int flags, int fid, double* uv, Point3*); //evaluation routine
  Point3 ctr() { return _gpmesh.ctr(); }
  void bbx(Point3& bbmin, Point3& bbmax) { _gpmesh.bbx(bbmin,bbmax); }
  //ops
  int subdivide(int lvl);
  int midsub(int lvl);
  int dump();
  //access
  int numf() { return _gpmesh.numf(); }
  int numv() { return _gpmesh.numv(); }
};



#endif
