#include "blas.h"
#include "lapack.h"
#include "numvec.hpp"
#include "nummat.hpp"
#include "numtns.hpp"

#include "vecmatop.hpp"

using std::cerr;

//Y <- a M X + b Y
// ---------------------------------------------------------------------- 
int dgemm(double alpha, const DblNumMat& A, const DblNumMat& B, double beta, DblNumMat& C)
{
  assert( A.m() == C.m() );  assert( A.n() == B.m() );  assert( B.n() == C.n() );
  iC( dgemm(C.m(), C.n(), A.n(), alpha, A.data(), B.data(), beta, C.data()) );
  return 0;
}
// ---------------------------------------------------------------------- 
int dgemm(int m, int n, int k, double alpha, double* A, double* B, double beta, double* C)
{
  char transa = 'N';
  char transb = 'N';
  assert(m!=0 && n!=0 && k!=0);
  dgemm_(&transa, &transb, &m, &n, &k,
		 &alpha, A, &m, B, &k, &beta, C, &m);
  return 0;
}
//Y <- a M X + b Y
// ---------------------------------------------------------------------- 
int dgemv(double alpha, const DblNumMat& A, const DblNumVec& X, double beta, DblNumVec& Y)
{
  assert(Y.m() == A.m());
  assert(A.n() == X.m());
  iC( dgemv(A.m(), A.n(), alpha, A.data(), X.data(), beta, Y.data()) );
  return 0;
}
// ---------------------------------------------------------------------- 
int dgemv(int m, int n, double alpha, double* A, double* X, double beta, double* Y)
{
  char trans = 'N';
  assert(m!=0 && n!=0);
  int incx = 1;
  int incy = 1;
  dgemv_(&trans, &m, &n, &alpha, A, &m, X, &incx, &beta, Y, &incy);
  return 0;
}




// ---------------------------------------------------------------------- 
int zgemm(cpx alpha, const CpxNumMat& A, const CpxNumMat& B, cpx beta, CpxNumMat& C)
{
  assert( A.m() == C.m() );  assert( A.n() == B.m() );  assert( B.n() == C.n() );
  iC( zgemm(C.m(), C.n(), A.n(), alpha, A.data(), B.data(), beta, C.data()) );
  return 0;
}
// ---------------------------------------------------------------------- 
int zgemm(int m, int n, int k, cpx alpha, cpx* A, cpx* B, cpx beta, cpx* C)
{
  char transa = 'N';
  char transb = 'N';
  assert(m!=0 && n!=0 && k!=0);
  zgemm_(&transa, &transb, &m, &n, &k,
		 &alpha, A, &m, B, &k, &beta, C, &m);
  return 0;
}
//Y <- a M X + b Y
// ---------------------------------------------------------------------- 
int zgemv(cpx alpha, const CpxNumMat& A, const CpxNumVec& X, cpx beta, CpxNumVec& Y)
{
  assert(Y.m() == A.m());
  assert(A.n() == X.m());
  iC( zgemv(A.m(), A.n(), alpha, A.data(), X.data(), beta, Y.data()) );
  return 0;
}
// ---------------------------------------------------------------------- 
int zgemv(int m, int n, cpx alpha, cpx* A, cpx* X, cpx beta, cpx* Y)
{
  char trans = 'N';
  assert(m!=0 && n!=0);
  int incx = 1;
  int incy = 1;
  zgemv_(&trans, &m, &n, &alpha, A, &m, X, &incx, &beta, Y, &incy);
  return 0;
}


// ---------------------------------------------------------------------- 
int spev1d(int evflag, int dmflag, int dof, double* data, int m, double e, int i, double u, double* res)
{
  int is[4];
  if(dmflag==DMFLAG_PERIOD) {
	 for(int k=0; k<4; k++) is[k]=(i+k-1 + m) % m;
  } else {
	 assert(i>=1 && i<=m-3);
	 for(int k=0; k<4; k++) is[k]=(i+k-1);
  }
  DblNumMat M(dof,m,false,data); //assert(M.n()==n && M.m()==res.m()); //double dof = M.m();  //int cnt = 0;
  //---------------------------
  if(evflag & EVFLAG_VL) {
	 double scl = 1.0;
	 double us[4]; iC( spcoef(EVFLAG_VL, u, us) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int d=0; d<dof; d++) 
		for(int a=0; a<4; a++) {
		  res[d] += us[a] * M(d,is[a]);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl; //scaling
	 res+=dof;
  }
  //---------------------------
  if(evflag & EVFLAG_FD) {
	 double scl = double(m) / e;
	 double us[4]; iC( spcoef(EVFLAG_FD, u, us) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int d=0; d<dof; d++)
		for(int a=0; a<4; a++) {
		  res[d] += us[a] * M(d,is[a]);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl; //scaling
	 res+=dof;
  }
  //---------------------------
  if(evflag & EVFLAG_SD) {
	 double scl = double(m*m)/(e*e);
	 double us[4]; iC( spcoef(EVFLAG_SD, u, us) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int d=0; d<dof; d++)
		for(int a=0; a<4; a++) {
		  res[d] += us[a] * M(d,is[a]);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl; //scaling
	 res+=dof;
  }
  return 0;
}
// ---------------------------------------------------------------------- 
int spev2d(int evflag, int dmflag, int dof, double* data, int* mn, double* ef, int* ij, double* uv, double* res)
{
  int m = mn[0];  int n = mn[1];
  double e = ef[0];  double f = ef[1];
  int i = ij[0];  int j = ij[1];
  double u = uv[0];  double v = uv[1];
  
  int is[4]; int js[4];
  if(dmflag==DMFLAG_PERIOD) {
	 for(int k=0; k<4; k++) is[k]=(i+k-1 + m) % m;
	 for(int k=0; k<4; k++) js[k]=(j+k-1 + n) % n;
  } else {
	 assert(i>=1 && i<=m-3);
	 for(int k=0; k<4; k++)	is[k]=(i+k-1);
	 assert(j>=1 && j<=n-3);
	 for(int k=0; k<4; k++) js[k]=(j+k-1);
  }
  DblNumMat M(dof,m*n,false,data);
  double scl;
  double us[4], vs[4];
  //---------------------------
  if(evflag & EVFLAG_VL) {
	 scl = 1.0;
	 iC( spcoef(EVFLAG_VL, u, us) );
	 iC( spcoef(EVFLAG_VL, v, vs) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int a=0; a<4; a++)
		for(int b=0; b<4; b++) {
		  double coef = us[a]*vs[b]; 
		  for(int d=0; d<dof; d++)
			 res[d] += coef * M(d, is[a]+js[b]*m);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl;
	 res+=dof;
  }
  //---------------------------
  if(evflag & EVFLAG_FD) {
	 scl = double(m)/e;
	 iC( spcoef(EVFLAG_FD, u, us) );
	 iC( spcoef(EVFLAG_VL, v, vs) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int a=0; a<4; a++)
		for(int b=0; b<4; b++) {
		  double coef = us[a]*vs[b];
		  for(int d=0; d<dof; d++)
			 res[d] += coef * M(d, is[a]+js[b]*m);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl;
	 res+=dof;
	 //...
	 scl = double(n)/f;
	 iC( spcoef(EVFLAG_VL, u, us) );
	 iC( spcoef(EVFLAG_FD, v, vs) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int a=0; a<4; a++)
		for(int b=0; b<4; b++) {
		  double coef = us[a]*vs[b]; 
		  for(int d=0; d<dof; d++)
			 res[d] += coef * M(d, is[a]+js[b]*m);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl;
	 res+=dof;
  }
  //---------------------------
  if(evflag & EVFLAG_SD) {
	 scl = double(m*m)/(e*e);
	 iC( spcoef(EVFLAG_SD, u, us) );
	 iC( spcoef(EVFLAG_VL, v, vs) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int a=0; a<4; a++)
		for(int b=0; b<4; b++) {
		  double coef = us[a]*vs[b]; 
		  for(int d=0; d<dof; d++)
			 res[d] += coef * M(d, is[a]+js[b]*m);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl;
	 res+=dof;
	 //...
	 scl = double(m*n)/(e*f);
	 iC( spcoef(EVFLAG_FD, u, us) );
	 iC( spcoef(EVFLAG_FD, v, vs) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int a=0; a<4; a++)
		for(int b=0; b<4; b++) {
		  double coef = us[a]*vs[b]; 
		  for(int d=0; d<dof; d++)
			 res[d] += coef * M(d, is[a]+js[b]*m);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl;
	 res+=dof;
	 //...
	 scl = double(n*n)/(f*f);
	 iC( spcoef(EVFLAG_VL, u, us) );
	 iC( spcoef(EVFLAG_SD, v, vs) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int a=0; a<4; a++)
		for(int b=0; b<4; b++) {
		  double coef = us[a]*vs[b]; 
		  for(int d=0; d<dof; d++)
			 res[d] += coef * M(d, is[a]+js[b]*m);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl;
	 res+=dof;
  }
  return 0;
}
// ---------------------------------------------------------------------- 
int spcoef(int evflag, double u, double* us)
{
  double u1 = u;
  double u2 = u*u;
  double u3 = u*u*u;
  if(       evflag==EVFLAG_VL) {
	 us[0] = (  1 - 3*u1 + 3*u2 -   u3)/6.0;
	 us[1] = (  4        - 6*u2 + 3*u3)/6.0;
	 us[2] = (  1 + 3*u1 + 3*u2 - 3*u3)/6.0;
	 us[3] = (                  +   u3)/6.0;
  } else if(evflag==EVFLAG_FD) {
	 us[0] = (- 3 + 6*u1 - 3*u2)/6.0;
	 us[1] = (    -12*u1 + 9*u2)/6.0;
	 us[2] = (  3 + 6*u1 - 9*u2)/6.0;
	 us[3] = (             3*u2)/6.0;
  } else if(evflag==EVFLAG_SD) {
	 us[0] = (  6 - 6*u1 ) / 6.0;
	 us[1] = (-12 +18*u1 ) / 6.0;
	 us[2] = (  6 -18*u1 ) / 6.0;
	 us[3] = (      6*u1 ) / 6.0;	 //assert(0); //TODO;
  }  
  return 0;
}
// -------------------------------------------------------------------------------------------------------------------------------------
// ---------------------------------------------------------------------- 
int lagev1d(int evflag, int dmflag, int dof, double* data, int m, double e, int i, double u, double* res)
{
  int is[4];
  if(dmflag==DMFLAG_PERIOD) {
	 for(int k=0; k<4; k++) is[k]=(i+k-1 + m) % m;
  } else {
	 assert(i>=1 && i<=m-3);
	 for(int k=0; k<4; k++) is[k]=(i+k-1);
  }
  DblNumMat M(dof,m,false,data); //assert(M.n()==n && M.m()==res.m()); //double dof = M.m();  //int cnt = 0;
  //---------------------------
  if(evflag & EVFLAG_VL) {
	 double scl = 1.0;
	 double us[4]; iC( lagcoef(EVFLAG_VL, u, us) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int d=0; d<dof; d++) 
		for(int a=0; a<4; a++) {
		  res[d] += us[a] * M(d,is[a]);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl; //scaling
	 res+=dof; //cnt ++;
  }
  //---------------------------
  if(evflag & EVFLAG_FD) {
	 double scl = double(m) / e;
	 double us[4]; iC( lagcoef(EVFLAG_FD, u, us) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int d=0; d<dof; d++)
		for(int a=0; a<4; a++) {
		  res[d] += us[a] * M(d,is[a]);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl; //scaling
	 res+=dof; //cnt ++;
  }
  //---------------------------
  if(evflag & EVFLAG_SD) {
	 double scl = double(m*m)/(e*e);
	 double us[4]; iC( lagcoef(EVFLAG_SD, u, us) );
	 for(int d=0; d<dof; d++)		res[d] = 0;
	 for(int d=0; d<dof; d++)
		for(int a=0; a<4; a++) {
		  res[d] += us[a] * M(d,is[a]);
		}
	 for(int d=0; d<dof; d++)		res[d] *= scl; //scaling
	 res+=dof; //cnt ++;
  }
  return 0;
}
// ----------------------------------------------------------------------
int lagev2d(int evflag, int dmflag, int dof, double* data, int* mn, double* ef, int* ij, double* uv, double* res)
{
  int m = mn[0];  int n = mn[1];
  double e = ef[0];  double f = ef[1];
  int i = ij[0];  int j = ij[1];
  double u = uv[0];  double v = uv[1];
  
  int is[4]; int js[4];
  if(dmflag==DMFLAG_PERIOD) {
    for(int k=0; k<4; k++) is[k]=(i+k-1 + m) % m;
    for(int k=0; k<4; k++) js[k]=(j+k-1 + n) % n;
  } else {
    assert(i>=1 && i<=m-3);
    for(int k=0; k<4; k++)	is[k]=(i+k-1);
    assert(j>=1 && j<=n-3);
    for(int k=0; k<4; k++) js[k]=(j+k-1);
  }
  DblNumMat M(dof,m*n,false,data);
  double scl;
  double us[4], vs[4];
  //---------------------------
  if(evflag & EVFLAG_VL) {
    scl = 1.0;
    iC( lagcoef(EVFLAG_VL, u, us) );
    iC( lagcoef(EVFLAG_VL, v, vs) );
    for(int d=0; d<dof; d++)		res[d] = 0;
    for(int a=0; a<4; a++)
      for(int b=0; b<4; b++) {
	double coef = us[a]*vs[b];
	for(int d=0; d<dof; d++)
	  res[d] += coef * M(d, is[a]+js[b]*m);
      }
    for(int d=0; d<dof; d++)		res[d] *= scl;
    res+=dof;
  }
  //---------------------------
  if(evflag & EVFLAG_FD) {
    scl = double(m)/e;
    iC( lagcoef(EVFLAG_FD, u, us) );
    iC( lagcoef(EVFLAG_VL, v, vs) );
    for(int d=0; d<dof; d++)		res[d] = 0;
    for(int a=0; a<4; a++)
      for(int b=0; b<4; b++) {
	double coef = us[a]*vs[b];
	for(int d=0; d<dof; d++)
	  res[d] += coef * M(d, is[a]+js[b]*m);
      }
    for(int d=0; d<dof; d++)		res[d] *= scl;
    res+=dof;
    //...
    scl = double(n)/f;
    iC( lagcoef(EVFLAG_VL, u, us) );
    iC( lagcoef(EVFLAG_FD, v, vs) );
    for(int d=0; d<dof; d++)		res[d] = 0;
    for(int a=0; a<4; a++)
      for(int b=0; b<4; b++) {
	double coef = us[a]*vs[b];
	for(int d=0; d<dof; d++)
	  res[d] += coef * M(d, is[a]+js[b]*m);
      }
    for(int d=0; d<dof; d++)		res[d] *= scl;
    res+=dof;
  }
  //---------------------------
  if(evflag & EVFLAG_SD) {
    scl = double(m*m)/(e*e);
    iC( lagcoef(EVFLAG_SD, u, us) );
    iC( lagcoef(EVFLAG_VL, v, vs) );
    for(int d=0; d<dof; d++)		res[d] = 0;
    for(int a=0; a<4; a++)
      for(int b=0; b<4; b++) {
	double coef = us[a]*vs[b];
	for(int d=0; d<dof; d++)
	  res[d] += coef * M(d, is[a]+js[b]*m);
      }
    for(int d=0; d<dof; d++)		res[d] *= scl;
    res+=dof;
    //...
    scl = double(m*n)/(e*f);
    iC( lagcoef(EVFLAG_FD, u, us) );
    iC( lagcoef(EVFLAG_FD, v, vs) );
    for(int d=0; d<dof; d++)		res[d] = 0;
    for(int a=0; a<4; a++)
      for(int b=0; b<4; b++) {
	double coef = us[a]*vs[b];
	for(int d=0; d<dof; d++)
	  res[d] += coef * M(d, is[a]+js[b]*m);
      }
    for(int d=0; d<dof; d++)		res[d] *= scl;
    res+=dof;
    //...
    scl = double(n*n)/(f*f);
    iC( lagcoef(EVFLAG_VL, u, us) );
    iC( lagcoef(EVFLAG_SD, v, vs) );
    for(int d=0; d<dof; d++)		res[d] = 0;
    for(int a=0; a<4; a++)
      for(int b=0; b<4; b++) {
	double coef = us[a]*vs[b];
	for(int d=0; d<dof; d++)
	  res[d] += coef * M(d, is[a]+js[b]*m);
      }
    for(int d=0; d<dof; d++)		res[d] *= scl;
    res+=dof;
  }
  return 0;
}
// ----------------------------------------------------------------------
int lagev3d(int evflag, int dmflag, int dof, double* data, int* mno, double* efg, int* ijk, double* uvw, double* res)
{
  assert(evflag==EVFLAG_VL);
  
  int m = mno[0];  int n = mno[1];  int o = mno[2];
  double e = efg[0];  double f = efg[1];  double g = efg[2];
  int i = ijk[0];  int j = ijk[1];  int k = ijk[2];
  double u = uvw[0];  double v = uvw[1];  double w = uvw[2];
  
  int is[4]; int js[4];  int ks[4];
  if(dmflag==DMFLAG_PERIOD) {
    for(int h=0; h<4; h++) is[h]=(i+h-1 + m) % m;
    for(int h=0; h<4; h++) js[h]=(j+h-1 + n) % n;
    for(int h=0; h<4; h++) ks[h]=(k+h-1 + o) % o;
  } else {
    assert(i>=1 && i<=m-3);
    for(int h=0; h<4; h++)	is[h]=(i+h-1);
    assert(j>=1 && j<=n-3);
    for(int h=0; h<4; h++) js[h]=(j+h-1);
    assert(k>=1 && k<=o-3);
    for(int h=0; h<4; h++) ks[h]=(k+h-1);
  }
  DblNumMat M(dof,m*n*o,false,data);
  double scl;
  double us[4], vs[4], ws[4];
  //---------------------------
  if(evflag & EVFLAG_VL) {
    scl = 1.0;
    iC( lagcoef(EVFLAG_VL, u, us) );
    iC( lagcoef(EVFLAG_VL, v, vs) );
    iC( lagcoef(EVFLAG_VL, w, ws) );
    for(int d=0; d<dof; d++)		res[d] = 0;
    for(int a=0; a<4; a++)
      for(int b=0; b<4; b++)
	for(int c=0; c<4; c++) {
	  double coef = us[a]*vs[b]*ws[c];
	  for(int d=0; d<dof; d++)
	    res[d] += coef * M(d, is[a]+js[b]*m+ks[c]*m*n);
	}
    for(int d=0; d<dof; d++)		res[d] *= scl;
    res+=dof;
  }
  return 0;
}
// ----------------------------------------------------------------------
int lagcoef(int evflag, double u, double* us)
{
  //double u1 = u;
  double u2 = u*u;
  double u3 = u*u*u;
  if(       evflag==EVFLAG_VL) {
	 us[0] = (u3-3*u2+2*u)/(-6.0);
	 us[1] = (u3-2*u2-u+2)/(2.0);
	 us[2] = (u3-u2-2*u)  /(-2.0);
	 us[3] = (u3-u)       /(6.0);
  } else if(evflag==EVFLAG_FD) {
	 us[0] = (3*u2-6*u+2)/(-6.0);
	 us[1] = (3*u2-4*u-1)/(2.0);
	 us[2] = (3*u2-2*u-2)/(-2.0);
	 us[3] = (3*u2-1)    /(6.0);
  } else if(evflag==EVFLAG_SD) {
	 assert(0); //TODO
  }
  return 0;
}
