#include "wave3d.hpp"

using std::cerr;

Wave3d* Wave3d::_self = NULL;

//-----------------------------------
Wave3d::Wave3d(const string& p): ComObject(p), _mlib(p+"_mlib"), _fplan(NULL), _bplan(NULL)
{
  _self = this;
}

//-----------------------------------
Wave3d::~Wave3d()
{
  _self = this;
  if(_fplan!=NULL) {	fftw_destroy_plan(_fplan);  }
  if(_bplan!=NULL) {	fftw_destroy_plan(_bplan);  }
}

//-----------------------------------
Index3 Wave3d::nml2dir(Point3 n, double W)
{
  int NPQ = 4;
  int C = NPQ * int(round(W));
  int B = C/2;
  int midx = 0;  double mval = abs(n(0));
  for(int d=1; d<3; d++)
    if(mval<abs(n(d))) {
      midx = d;	  mval = abs(n(d));
    }
  //midx gives the direction (can be + or -)
  Point3 val = n / mval;
  for(int d=0; d<3; d++)	val(d) = atan(val(d));
  double Ang = (M_PI/2)/C;
  Index3 res;
  for(int d=0; d<3; d++) {
    int tmp = int(floor(val(d)/Ang));
    tmp = min(max(tmp,-B), B-1);
    res(d) = 2*tmp + 1;
  }
  res(midx) = C*int(round(val(midx))); //val(midx)==1 or -1
  return res;
}

//-----------------------------------
Index3 Wave3d::predir(Index3 dir)
{
  int C = dir.linfty();
  int B = C/2;
  int midx = -1;
  for(int d=0; d<3; d++)	if(abs(dir(d))==C) midx = d;
  assert(midx!=-1);
  //midx gives the direction
  Index3 res;
  for(int d=0; d<3; d++)	res(d) = (dir(d) + C - 1) / 2;
  for(int d=0; d<3; d++)	res(d) = 2*(res(d)/2) + 1 - B;
  res(midx) = dir(midx) / 2;
  return res;
}

//-----------------------------------
vector<Index3> Wave3d::chddir(Index3 dir)
{
  int C = dir.linfty();
  int midx = -1;
  vector<int> oidx;
  for(int d=0; d<3; d++)
    if(abs(dir(d))==C)
      midx = d;
    else
      oidx.push_back(d);
  vector<Index3> res;
  for(int a=0; a<2; a++)
    for(int b=0; b<2; b++) {
      Index3 tmp = 2*dir;
      tmp(oidx[0]) += 2*a-1;
      tmp(oidx[1]) += 2*b-1;
      res.push_back(tmp);
    }
  return res;
}

//-----------------------------------
double Wave3d::dir2width(Index3 dir)
{
  int NPQ = 4;
  int C = dir.linfty();
  return double(C/NPQ);
}

