if(0)
  bs = bs(:);
  tmp = cell(numel(bs),1);
  for idx=1:numel(bs)
    tmp{idx} = bs(idx);
  end
  binstr = sprintf('%s_%d_%d_bcn%s',chgeo,K,NPW,chfld);
  fid = fopen(binstr,'w');
  string = {'vector',{'cpx'}};
  serialize(fid, tmp, string);
  fclose(fid);

  binstr = sprintf('%s_%d_%d_bcn%s',chgeo,K,NPW,chfld);
  fid = fopen(binstr,'r');
  string = {'CpxNumVec'};
  gg = deserialize(fid, string);
  fclose(fid);
  
  norm(gg-bs)

  
end


if(1)
  binstr = sprintf('%s_%d_%d_bcn%s',chgeo,K,NPW,chfld);
  fid = fopen(binstr,'w');
  string = {'CpxNumVec'};
  serialize(fid, bs, string);
  fclose(fid);
  
  binstr = sprintf('%s_%d_%d_bcn%s',chgeo,K,NPW,chfld);
  fid = fopen(binstr,'r');
  string = {'vector',{'cpx'}};
  tmp = deserialize(fid, string);
  
  gg = zeros(size(bs));
  for idx=1:numel(bs)
    gg(idx) = tmp{idx};
  end
  
  norm(gg-bs)
end
