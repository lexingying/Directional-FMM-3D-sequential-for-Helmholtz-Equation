#ifndef _ACOU3D_HPP_
#define _ACOU3D_HPP_

#include "comobject.hpp"
#include "vec3t.hpp"
#include "numtns.hpp"
#include "offtns.hpp"
#include "kernel3d.hpp"
#include "wave3d.hpp"
#include "petscsnes.h"

using std::vector;
using std::pair;
using std::map;
using std::set;
using std::cerr;
using std::cout;
using std::ostream;
using std::istream;

//---------------------------------------------------------------------------
class Acou3d: public ComObject
{
public:
  //input
  vector<Point3> _vertvec;
  vector<Index3> _facevec; //all triangle faces
  Point3 _ctr;
  int _accu;
  Kernel3d _knlbie;//what bie kernel to use
  //local
  vector<double> _diavec; //diagonal (solid angle/4pi)
  vector<double> _arevec; //length of each segment
  vector<Point3> _posvec; //pos used in fmm
  vector<Point3> _norvec; //nor used in fmm
  Wave3d _wave;
  map<int,DblNumMat> _gauwgts;
  map<int,DblNumMat> _sigwgts;
public:
  Acou3d(const string& p);
  ~Acou3d();
  //
  int setup(vector<Point3>& vertvec, vector<Index3>& facevec,
	    Point3 ctr, int accu, Kernel3d knlbie);
  //
  int solve(vector<cpx>& rhs, vector<cpx>& den);
  int mmult(vector<cpx>& in, vector<cpx>& ot);
  //PETSC stuff
  static int mmultWrapper(Mat, Vec, Vec);
  //
  int eval(vector<Point3>& chk, vector<cpx>& den, vector<cpx>& val);
};

#endif


