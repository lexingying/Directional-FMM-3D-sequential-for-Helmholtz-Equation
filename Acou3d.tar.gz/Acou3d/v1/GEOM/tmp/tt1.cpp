#include "ccsurf.hpp"
#include "ccsurfvr.hpp"
#include "serialize.hpp"

using namespace std;

int optionsCreate(int argc, char** argv, map<string,string>& options)
{
  options.clear();
  for(int k=1; k<argc; k=k+2) {
    options[ string(argv[k]) ] = string(argv[k+1]);
  }
  return 0;
}

//-------------------
int main(int argc, char** argv)
{
  srand48( (long)time(NULL) );
  map<string,string> opts;
  optionsCreate(argc, argv, opts);
  map<string,string>::iterator mi;
  vector<int> all(1,1);
  //input
  mi = opts.find("-meshfile"); assert(mi!=opts.end());
  char meshfile[100];  {istringstream ss((*mi).second);  ss>>meshfile;}
  mi = opts.find("-K");  assert(mi!=opts.end());
  double K;  {istringstream ss((*mi).second);  ss>>K;}
  mi = opts.find("-h");  assert(mi!=opts.end());
  double h;  {istringstream ss((*mi).second);  ss>>h;}
  //
  GpMesh gpmesh("gpmesh_");
  iC( gpmesh.setup(meshfile) );
  //center
  Point3 bbmin, bbmax;
  gpmesh.bbx(bbmin, bbmax);
  Point3 bbctr = (bbmin+bbmax)/2.0;
  double R = (bbctr-bbmin).linfty() * 1.25;
  vector<Point3>& points = gpmesh.points();
  for(int i=0; i<points.size(); i++)
    points[i] = (points[i]-bbctr)/R * (K/2);
  gpmesh.bbx(bbmin, bbmax);  cerr<<bbmin<<" | "<<bbmax<<endl;
  //
  CCSurf ccsurf("ccsurf_");
  iC( ccsurf.setup(gpmesh) );
  //subdivide
  typedef CCSurf::DataLevel DataLevel;
  bool done=false;
  while(done==false) {
    //subdivide
    iC( ccsurf.subdivide(ccsurf.posvec().size()-1) );
    //get size
    vector<DataLevel>& posvec = ccsurf.posvec();
    DataLevel& fm = posvec[posvec.size()-1];
    double maxdist = 0;
    double mindist = R;
    for(int f=0; f<fm.size(); f++) {
      CCRect<Point3>& CD = fm[f];
      int m = CD.m();
      int n = CD.n();
      for(int i=0; i<m-1; i++) {
	for(int j=0; j<n-1; j++) {
	  double len0 = (CD(i+1,j+1)-CD(i,j)).l2();
	  double len1 = (CD(i+1,j)-CD(i,j+1)).l2();
	  maxdist = max(maxdist,max(len0,len1));
	  mindist = min(mindist,min(len0,len1));
	}
      }
    }
    cerr<<maxdist<<" "<<mindist<<" "<<h<<endl;
    done = (maxdist<=h);
  }
  //
  int lvl = ccsurf.posvec().size()-1;
  DataLevel lmt;
  CCSurfOp::limit(ccsurf.gpmesh(), lvl, ccsurf.posvec()[lvl], lmt);
  DataLevel& fm = lmt;
  //random projection
  Point3 rnd(drand48()-0.5, drand48()-0.5, drand48()-0.5);
  rnd = rnd/rnd.l2();
  map<double,int> pimap;
  for(int f=0; f<fm.size(); f++) {
    CCRect<Point3>& CD = fm[f];
    int m = CD.m();
    int n = CD.n();
    for(int i=0; i<m; i++)
      for(int j=0; j<n; j++) {
	//pimap[CD(i,j)] = -1; //JUST TAKE A PLACE
	pimap[ dot(CD(i,j),rnd) ] = -1;
      }
  }
  //1. combine
  int vcnt = 0;
  map<double,int>::iterator cur = pimap.begin();
  map<double,int>::iterator nxt = cur; nxt++;
  (*cur).second = vcnt;  vcnt++;
  while(nxt!=pimap.end()) {
    double diff = abs((*nxt).first-(*cur).first);
    if(diff<1e-15) {
      (*nxt).second = (*cur).second;
    } else {
      (*nxt).second = vcnt; vcnt++;
    }
    cur++;
    nxt++;
  }
  //
  vector<Point3> vertvec(vcnt);
  vector<Index3> facevec;
  for(int f=0; f<fm.size(); f++) {
    CCRect<Point3>& CD = fm[f];
    int m = CD.m();
    int n = CD.n();
    CCRect<int> idxs(m,n);
    for(int i=0; i<m; i++)
      for(int j=0; j<n; j++) {
	map<double,int>::iterator cur = pimap.find( dot(CD(i,j),rnd) );
	idxs(i,j) = (*cur).second;
      }
    for(int i=0; i<m; i++)
      for(int j=0; j<n; j++) {
	vertvec[ idxs(i,j) ] = CD(i,j);
      }
    for(int i=0; i<m-1; i++)
      for(int j=0; j<n-1; j++) {
	int i00 = idxs(i,j);
	int i01 = idxs(i,j+1);
	int i10 = idxs(i+1,j);
	int i11 = idxs(i+1,j+1);
	facevec.push_back( Index3(i00,i10,i01) );
	facevec.push_back( Index3(i10,i11,i01) );
      }
  }
  cerr<<vertvec.size()<<" "<<facevec.size()<<" "<<vertvec.size()-facevec.size()/2<<endl;
  //serialzie
  mi = opts.find("-vertfile");  assert(mi!=opts.end());
  char vertname[100];  {istringstream ss((*mi).second);  ss>>vertname;}
  {ofstream fot(vertname); iC( serialize(vertvec, fot, all) ); }
  mi = opts.find("-facefile");  assert(mi!=opts.end());
  char facename[100];  {istringstream ss((*mi).second);  ss>>facename;}
  {ofstream fot(facename); iC( serialize(facevec, fot, all) ); }
  //
  CCSurfVr ccsurfvr(&argc, argv, &ccsurf, ccsurf.posvec().size()-1);
  glutMainLoop();
  return 0;
}
