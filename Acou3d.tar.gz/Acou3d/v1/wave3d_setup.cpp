#include "wave3d.hpp"

using std::istringstream;
using std::ifstream;
using std::ofstream;
using std::set;
using std::queue;
using std::cerr;

//---------------------------------------------------------------------
int Wave3d::setup(vector<Point3>& posvec, vector<Point3>& norvec,
		  Point3 ctr, int accu, Kernel3d knlbie)
{
  _self = this;
  _posvec = posvec;
  _norvec = norvec;
  _ctr = ctr;
  _accu = accu;  iA( _accu>=1 && _accu<=3 );
  _knlbie = knlbie;
  cerr<<"# points "<<posvec.size()<<endl;
  //mlib
  iA(_knlbie.type()==KNL_HELM_SING ||
     _knlbie.type()==KNL_HELM_DOUB ||
     _knlbie.type()==KNL_HELM_COMB);
  iC( _mlib.setup( Kernel3d(KNL_HELM_SING), _accu) );
  //figure out the following
  //_P
  if(       _accu==1) {
    _P = 4;
  } else if(_accu==2) {
    _P = 6;
  } else if(_accu==3) {
    _P = 8;
  }
  //_K
  double dist = 0;
  for(int k=0; k<_posvec.size(); k++) {
    Point3 p = posvec[k];
    dist = max(dist, (p-_ctr).linfty());
  }
  dist = dist*2; //get diameter
  int tmp = max(0, (int)ceil(log(dist)/log(2)));
  _K = pow2(tmp); cerr<<"K "<<_K<<endl; //LEXING
  _ptsmax = 60;
  _maxlevel = 16;
  //generate the tree, _ndevec
  _boxvec.clear();
  _bndvec.clear();
  iC( setup_tree() );
  //plans
  _denfft.resize(2*_P, 2*_P, 2*_P);
  _fplan = fftw_plan_dft_3d(2*_P,2*_P,2*_P,(fftw_complex*)(_denfft.data()),(fftw_complex*)(_denfft.data()), FFTW_FORWARD,FFTW_MEASURE);
  iA(_fplan!=NULL);
  setvalue(_denfft,cpx(0,0));
  //
  _valfft.resize(2*_P, 2*_P, 2*_P);
  _bplan = fftw_plan_dft_3d(2*_P,2*_P,2*_P,(fftw_complex*)(_valfft.data()),(fftw_complex*)(_valfft.data()), FFTW_BACKWARD,FFTW_MEASURE); 
  iA(_bplan!=NULL);
  setvalue(_valfft,cpx(0,0));
  return 0;
}

//---------------------------------------------------------------------
int Wave3d::setup_tree()
{
  double eps = 1e-12;
  int sdof = 1;
  int tdof = 1;
  double R = width()/2.0;
  Point3 bbmin( _ctr-Point3(R,R,R) );
  Point3 bbmax( _ctr+Point3(R,R,R) );
  BoxDat curdat;
  for(int k=0; k<_posvec.size(); k++) {
    Point3 tmp = _posvec[k];
    iA( (tmp[0]>=bbmin[0] && tmp[1]>=bbmin[1] && tmp[2]>=bbmin[2]) &&
	(tmp[0]<=bbmax[0] && tmp[1]<=bbmax[1] && tmp[2]<=bbmax[2]) ); //IMPORTANT
    curdat.ptidxvec().push_back(k);
  }
  queue< pair<BoxKey,BoxDat> > tmpq;
  BoxKey curkey;
  curkey.first = 0;  curkey.second = Index3(0,0,0);
  tmpq.push( pair<BoxKey,BoxDat>(curkey,curdat) );
  //--- tree
  while(tmpq.empty()==false) {
    pair<BoxKey,BoxDat> curent = tmpq.front();	tmpq.pop();
    BoxKey& curkey = curent.first;
    BoxDat& curdat = curent.second;
    //LEXING: VERY IMPORTANT
    if(curdat.ptidxvec().size()>0)
      curdat.tag() = curdat.tag() | WAVE3D_PTS;
    bool action = (curkey.first<=unitlevel() && curdat.ptidxvec().size()>0) ||
      (curdat.ptidxvec().size()>_ptsmax && curkey.first<_maxlevel-1);
    if(action) {
      //1. subdivide to get new children
      NumTns<BoxDat> chdboxtns(2,2,2);
      Point3 curctr = center(curkey); //LEXING: VERY IMPORTANT
      for(int g=0; g<curdat.ptidxvec().size(); g++) {
	int tmpidx = curdat.ptidxvec()[g];
	Point3 tmp = _posvec[tmpidx];
	Index3 idx;
	for(int d=0; d<3; d++)		  idx(d) = (tmp(d)>=curctr(d));
	chdboxtns(idx(0),idx(1),idx(2)).ptidxvec().push_back(tmpidx); //put points to children
      }
      //2. put non-empty ones into queue
      for(int a=0; a<2; a++)
	for(int b=0; b<2; b++)
	  for(int c=0; c<2; c++) {
	    //if(chdboxtns(a,b,c).ptidxvec().size()>0)
	    BoxKey chdkey = this->chdkey(curkey, Index3(a,b,c));
	    tmpq.push( pair<BoxKey,BoxDat>(chdkey, chdboxtns(a,b,c)) );
	  }
      //4. clear my own ptidxvec vector
      curdat.ptidxvec().clear();
    } else {
      //1. copy data into _extpos
      curdat.extpos().resize(3, curdat.ptidxvec().size());
      curdat.extnor().resize(3, curdat.ptidxvec().size());
      for(int g=0; g<curdat.ptidxvec().size(); g++) {
	int tmpidx = curdat.ptidxvec()[g];
	Point3 tmppos = _posvec[tmpidx];
	for(int d=0; d<3; d++)	  curdat.extpos()(d,g) = tmppos(d);
	Point3 tmpnor = _norvec[tmpidx];
	for(int d=0; d<3; d++)	  curdat.extnor()(d,g) = tmpnor(d);
      }
      //LEXING: VERY IMPORTANT
      curdat.tag() = curdat.tag() | WAVE3D_TERMINAL;
    }
    //add my self into _tree
    _boxvec[curkey] = curdat;    //_boxvec.insert(curkey, curdat); //LEXING: CHECK
  }
  cerr<<"setup_tree, done tree"<<endl;
  //compute lists (top down)
  for(map<BoxKey,BoxDat>::iterator mi=_boxvec.begin(); mi!=_boxvec.end(); mi++) {
    BoxKey curkey = (*mi).first;
    BoxDat& curdat = (*mi).second;
    if(curdat.tag()&WAVE3D_PTS) { //LEXING: JUST COMPUTE MY OWN BOXES
      if(width(curkey)<1-eps) { //LEXING: STRICTLY < 1
	iC( setup_tree_callowlist(curkey, curdat) );
      } else {
	iC( setup_tree_calhghlist(curkey, curdat) );
      }
    }
  }
  cerr<<"setup_tree, done lists"<<endl;
  //preset low freq data in each node
  for(map<BoxKey,BoxDat>::iterator mi=_boxvec.begin(); mi!=_boxvec.end(); mi++) {
    BoxKey curkey = (*mi).first;
    BoxDat& curdat = (*mi).second;
    if(curdat.tag() & WAVE3D_PTS) {
      for(vector<BoxKey>::iterator vi=curdat.vndeidxvec().begin(); vi!=curdat.vndeidxvec().end(); vi++) {
	BoxKey neikey = (*vi);
	BoxDat& neidat = _boxvec[neikey]; //LEXING: CHECK
	neidat.fftnum() ++;
      }
    }
  }
  //high freq
  for(map<BoxKey,BoxDat>::iterator mi=_boxvec.begin(); mi!=_boxvec.end(); mi++) {
    BoxKey curkey = (*mi).first;
    BoxDat& curdat = (*mi).second;
    double W = width(curkey);
    if(W>1-eps && (curdat.tag()&WAVE3D_PTS)) {
      if(isroot(curkey)==false) {
	BoxKey parkey = this->parkey(curkey);
	BoxDat& pardat = _boxvec[parkey]; //LEXING: CHECK
	for(set<Index3>::iterator si=pardat.outdirset().begin(); si!=pardat.outdirset().end(); si++) {
	  Index3 nowdir = predir(*si);
	  curdat.outdirset().insert(nowdir);
	}
	for(set<Index3>::iterator si=pardat.incdirset().begin(); si!=pardat.incdirset().end(); si++) {
	  Index3 nowdir = predir(*si);
	  curdat.incdirset().insert(nowdir);
	}
      }
      //go thrw
      Point3 curctr = center(curkey);
      for(map< Index3,vector<BoxKey> >::iterator mi=curdat.fndeidxvec().begin(); mi!=curdat.fndeidxvec().end(); mi++) {
	vector<BoxKey>& tmplist = (*mi).second;
	for(int k=0; k<tmplist.size(); k++) {
	  BoxKey othkey = tmplist[k];
	  //BoxDat& othdat = _boxvec.access(othkey);
	  Point3 othctr = center(othkey);
	  Point3 tmp;
	  if(othkey>curkey)
	    tmp = othctr-curctr;
	  else
	    tmp = -(curctr-othctr);
	  tmp = tmp/tmp.l2();
	  Index3 dir = nml2dir(tmp, W);
	  curdat.outdirset().insert(dir);
	  if(curkey>othkey)
	    tmp = curctr-othctr;
	  else
	    tmp = -(othctr-curctr);
	  tmp = tmp/tmp.l2();
	  dir = nml2dir(tmp, W);
	  curdat.incdirset().insert(dir);
	}
      }
    }
  }
  cerr<<"setup_tree, done low, high data"<<endl;
  return 0;
}


//---------------------------------------------------------------------
int Wave3d::setup_tree_callowlist(BoxKey curkey, BoxDat& curdat)
{
  set<BoxKey> Uset, Vset, Wset, Xset;
  //const BoxKey& curkey = curent.first;
  //const BoxDat& curdat = curent.second;
  iA(isroot(curkey)==false); //LEXING: DO NOT ALLOW WIDTH=1 BOXES TO BE CELLS
  Index3 curpth = curkey.second;
  BoxKey parkey = this->parkey(curkey); //the link to parent
  Index3 parpth = parkey.second;
  //
  int L = pow2(curkey.first);  //Index3 minpth(0,0,0);  //Index3 maxpth(L,L,L);
  int il, iu, jl,ju, kl, ku;
  il = max(2*parpth(0)-2,0);	iu = min(2*parpth(0)+4,L);
  jl = max(2*parpth(1)-2,0);	ju = min(2*parpth(1)+4,L);
  kl = max(2*parpth(2)-2,0);	ku = min(2*parpth(2)+4,L);
  for(int i=il; i<iu; i++)
    for(int j=jl; j<ju; j++)
      for(int k=kl; k<ku; k++) {
	Index3 trypth(i,j,k);
	if( (trypth(0)==curpth(0) && trypth(1)==curpth(1) && trypth(2)==curpth(2))==false ) {
	  BoxKey wntkey(curkey.first, trypth);
	  //LEXING: LOOK FOR IT, DO NOT EXIST IF NO CELL BOX COVERING IT
	  BoxKey reskey;
	  bool found = setup_tree_find(wntkey, reskey);
	  BoxDat& resdat = _boxvec[reskey]; //LEXING: CHECK
	  if(found) {
	    bool adj = setup_tree_adjacent(reskey, curkey);
	    if( reskey.first<curkey.first ) {
	      if(adj) {
		if(isterminal(curdat)) {
		  if(resdat.tag()&WAVE3D_PTS)
		    Uset.insert(reskey);
		}
	      } else {
		if(resdat.tag()&WAVE3D_PTS)
		  Xset.insert(reskey);
	      }
	    }
	    if( reskey.first==curkey.first ) {
	      if(!adj) {
		Index3 bb = reskey.second - curkey.second;				iA( bb.linfty()<=3 );
		if(resdat.tag()&WAVE3D_PTS)
		  Vset.insert(reskey);
	      } else {
		if(isterminal(curdat)) {
		  queue<BoxKey> rest;
		  rest.push(reskey);
		  while(rest.empty()==false) {
		    BoxKey fntkey = rest.front(); rest.pop();
		    BoxDat& fntdat = _boxvec[fntkey]; //LEXING: CHECK
		    if(setup_tree_adjacent(fntkey, curkey)==false) {
		      if(fntdat.tag()&WAVE3D_PTS)
			Wset.insert(fntkey);
		    } else {
		      if(isterminal(fntdat)) {
			if(fntdat.tag()&WAVE3D_PTS)
			  Uset.insert(fntkey);
		      } else {
			for(int a=0; a<2; a++)
			  for(int b=0; b<2; b++)
			    for(int c=0; c<2; c++)
			      rest.push( chdkey(fntkey, Index3(a,b,c)) );
		      }
		    }
		  }
		}
	      }
	    }
	  }
	}
      }
  if(isterminal(curdat))
    if(curdat.tag()&WAVE3D_PTS)
      Uset.insert(curkey);
  //
  for(set<BoxKey>::iterator si=Uset.begin(); si!=Uset.end(); si++)
	curdat.undeidxvec().push_back(*si);
  for(set<BoxKey>::iterator si=Vset.begin(); si!=Vset.end(); si++)
	curdat.vndeidxvec().push_back(*si);
  for(set<BoxKey>::iterator si=Wset.begin(); si!=Wset.end(); si++)
	curdat.wndeidxvec().push_back(*si);
  for(set<BoxKey>::iterator si=Xset.begin(); si!=Xset.end(); si++)
	curdat.xndeidxvec().push_back(*si);
  return 0;
}

//---------------------------------------------------------------------
int Wave3d::setup_tree_calhghlist(BoxKey curkey, BoxDat& curdat)
{
  int NPQ = 4;
  Point3 curctr = center(curkey);
  double W = width(curkey);
  int C = NPQ*int(round(W));
  double eps = 1e-12;
  double D = W*W + W;
  if(isroot(curkey)==true) {
    curdat.endeidxvec().push_back(curkey);
    /*
    //LEXING: CHECK THE FOLLOWING
    for(map<BoxKey,BoxDat>::iterator mi=_boxvec.lclmap().begin(); isroot((*mi).first)==true; mi++) {
      BoxKey othkey = (*mi).first;
      BoxDat& othdat = _boxvec.access(othkey);
      if(othdat.tag() & WAVE3D_PTS) {
	//LEXING: ALWAYS target - source //Point3 diff = curctr - center(othkey);
	Point3 diff;
	if(curkey>othkey)
	  diff = curctr-center(othkey);
	else
	  diff = -(center(othkey)-curctr);
	if(diff.l2()>=D-eps) {
	  Index3 dir = nml2dir(diff/diff.l2(), W);
	  curdat.fndeidxvec()[dir].push_back(othkey);
	} else {
	  curdat.endeidxvec().push_back(othkey);
	}
      }
    }
    */
  } else {
    BoxKey parkey = this->parkey(curkey);
    BoxDat& pardata = _boxvec[parkey]; //LEXING: CHECK
    for(int k=0; k<pardata.endeidxvec().size(); k++) {
      BoxKey trykey = pardata.endeidxvec()[k];
      BoxDat& trydata = _boxvec[trykey]; //LEXING: CHECK
      for(int a=0; a<2; a++)
	for(int b=0; b<2; b++)
	  for(int c=0; c<2; c++) {
	    BoxKey othkey = chdkey(trykey, Index3(a,b,c));
	    BoxDat& othdat = _boxvec[othkey]; //LEXING: CHECK
	    if(othdat.tag() & WAVE3D_PTS) {
	      //LEXING: ALWAYS target - source
	      Point3 diff;
	      if(curkey>othkey)
		diff = curctr-center(othkey);
	      else
		diff = -(center(othkey)-curctr);
	      if(diff.l2()>=D-eps) {
		Index3 dir = nml2dir(diff/diff.l2(), W);
		curdat.fndeidxvec()[dir].push_back(othkey);
	      } else {
		curdat.endeidxvec().push_back(othkey);
	      }
	    }
	  }
    }
  }
  return 0;
}

// ----------------------------------------------------------------------
bool Wave3d::setup_tree_find(BoxKey wntkey, BoxKey& trykey)
{
  trykey = wntkey;
  while(isroot(trykey)==false) {
    map<BoxKey,BoxDat>::iterator mi=_boxvec.find(trykey);
    if(mi!=_boxvec.end())
      return true; //found
    trykey = parkey(trykey);
  }
  map<BoxKey,BoxDat>::iterator mi=_boxvec.find(trykey);
  return (mi!=_boxvec.end());
}

// ----------------------------------------------------------------------
bool Wave3d::setup_tree_adjacent(BoxKey meekey, BoxKey youkey)
{
  int md = max(meekey.first,youkey.first);
  Index3 one(1,1,1);
  Index3 meectr(  (2*meekey.second+one) * pow2(md - meekey.first)  );
  Index3 youctr(  (2*youkey.second+one) * pow2(md - youkey.first)  );
  int meerad = pow2(md - meekey.first);
  int yourad = pow2(md - youkey.first);
  Index3 dif( ewabs(meectr-youctr) );
  int rad  = meerad + yourad;
  return
    (dif[0]<=rad && dif[1]<=rad && dif[2]<=rad) &&
    ( dif.linfty() == rad ); //at least one edge touch
}

  /*
  ofstream fot;
  fot.open("tree");
  for(int i=0; i<_ndevec.size(); i++) {
  int curidx = i;
  Node& curnde = _ndevec[curidx];
  fot<<curidx<<" &&& ";
  fot<<curnde.paridx()<<" | "<<curnde.chdstt()<<" | "<<curnde.path()<<" | "<<curnde.depth()<<" | TAG "<<curnde.tag()<<" | PTZ "<<curnde.ptidxvec().size()<<" &&& ";	
  fot<<curnde.undeidxvec().size()<<" | "<<curnde.vndeidxvec().size()<<" | "<<curnde.wndeidxvec().size()<<" | "<<curnde.xndeidxvec().size()<<" | "
  <<curnde.fndeidxvec().size()<<" | "<<curnde.endeidxvec().size()<<" &&& ";
  fot<<curnde.outdirdatamap().size()<<" | "<<curnde.incdirdatamap().size()<<endl;
  }
  fot.close();
  */
