%------------------------------------------------------------
chgeo = 'four';
chfld = 'yz-'; %yz-
chchk = 'xyz=0';
K = 32;
NPW = 5;

%before c
if(1)
  %--------

  binstr = sprintf('four_%d_%d_vert',K,NPW);
  fid = fopen(binstr,'r');
  string = {'vectorPoint3'};
  vs = deserialize(fid, string);
  fclose(fid);
  
  binstr = sprintf('four_%d_%d_face',K,NPW);
  fid = fopen(binstr,'r');
  string = {'vectorIndex3'};
  fs = deserialize(fid, string);
  fclose(fid);
  
  if(0)
    binstr = sprintf('four_%d_%d_vert',K,NPW);
    fid = fopen(binstr,'r');
    string = {'vector',{'Point3'}};
    vert = deserialize(fid, string);
    fclose(fid);
    
    binstr = sprintf('four_%d_%d_face',K,NPW);
    fid = fopen(binstr,'r');
    string = {'vector',{'Index3'}};
    face = deserialize(fid, string);
    fclose(fid);
    
    vs = zeros(3,numel(vert));
    for a=1:numel(vert)
      vs(:,a) = vert{a};
    end
    fs = zeros(3,numel(face));
    for a=1:numel(face)
      fs(:,a) = face{a};
    end
  end
  
  %----------
  if(    strcmp(chfld,'z-')==1)
    dir = [0,0,-1];
    off = vs(1,:)*dir(1) + vs(2,:)*dir(2) + vs(3,:)*dir(3);
    bs = - exp(2*pi*i*off); %neg
  elseif(strcmp(chfld,'z+')==1)
    dir = [0,0,1];
    off = vs(1,:)*dir(1) + vs(2,:)*dir(2) + vs(3,:)*dir(3);
    bs = - exp(2*pi*i*off); %neg
  elseif(strcmp(chfld,'yz-')==1)
    dir = [0,-1,-1]; dir=dir/norm(dir);
    off = vs(1,:)*dir(1) + vs(2,:)*dir(2) + vs(3,:)*dir(3);
    bs = - exp(2*pi*i*off); %neg
  elseif(strcmp(chfld,'xyz-')==1)
    dir = [-1,-1,-1]; dir=dir/norm(dir);
    off = vs(1,:)*dir(1) + vs(2,:)*dir(2) + vs(3,:)*dir(3);
    bs = - exp(2*pi*i*off); %neg
  else
    error('wrong');
  end
  tmp = cell(numel(bs),1);
  for idx=1:numel(bs)
    tmp{idx} = bs(idx);
  end
  binstr = sprintf('%s_%d_%d_bcn%s',chgeo,K,NPW,chfld);
  fid = fopen(binstr,'w');
  string = {'vector',{'cpx'}};
  serialize(fid, tmp, string);
  fclose(fid);
  
  hold on; trimesh(fs'+1,vs(1,:),vs(2,:),vs(3,:),real(off));
  
  %----------
  if(    strcmp(chchk,'x=0')==1) 
    step=1/8;
    R = K/2;
    tmp = [-R+step/2:step:R];
    [ys,zs] = ndgrid(tmp);
    xs = zeros(size(ys));
    ps = [xs(:)';ys(:)';zs(:)'];
  elseif(strcmp(chchk,'xyz=0')==1)
    step=1/8;
    R = K/2;
    tmp = [-R+step/2:step:R];
    ps = [];
    [ys,zs] = ndgrid(tmp);
    xs = zeros(size(ys));
    ps = [ps [xs(:)';ys(:)';zs(:)']];
    [zs,xs] = ndgrid(tmp);
    ys = zeros(size(zs));
    ps = [ps [xs(:)';ys(:)';zs(:)']];
    [xs,ys] = ndgrid(tmp);
    zs = zeros(size(xs));
    ps = [ps [xs(:)';ys(:)';zs(:)']];
  else
    error('wrong');
  end
  NC = size(ps,2);
  tmp = cell(NC,1);
  for idx=1:NC
    tmp{idx} = [ps(1,idx),ps(2,idx),ps(3,idx)];
  end
  binstr = sprintf('%s_%d_%d_chk%s',chgeo,K,NPW,chchk);
  fid = fopen(binstr,'w');
  string = {'vector',{'Point3'}};
  serialize(fid,tmp,string);
  fclose(fid);
  hold on; plot3(ps(1,:), ps(2,:), ps(3,:), '+'); axis equal;
end

%after c
if(0)
  binstr = sprintf('%s_%d_%d_den%s',chgeo,K,NPW,chfld);
  fid = fopen(binstr,'r');
  %string = {'vector',{'cpx'}};
  string = {'CpxNumVec'};
  den = deserialize(fid, string);
  fclose(fid);
  
  binstr = sprintf('%s_%d_%d_val%s',chgeo,K,NPW,chchk);
  fid = fopen(binstr,'r');
  %string = {'vector',{'cpx'}};
  string = {'CpxNumVec'};
  val = deserialize(fid, string);
  fclose(fid);
  
  if(    strcmp(chfld,'z-')==1)
    dir = [0,0,-1];
    off = ps(1,:)*dir(1) + ps(2,:)*dir(2) + ps(3,:)*dir(3);
    inc = exp(2*pi*i*off); %neg
    inc = inc(:);
  elseif(strcmp(chfld,'z+')==1)
    dir = [0,0,1];
    off = ps(1,:)*dir(1) + ps(2,:)*dir(2) + ps(3,:)*dir(3);
    inc = exp(2*pi*i*off); %neg
    inc = inc(:);
  elseif(strcmp(chfld,'yz-')==1)
    dir = [0,-1,-1]; dir=dir/norm(dir);
    off = ps(1,:)*dir(1) + ps(2,:)*dir(2) + ps(3,:)*dir(3);
    inc = exp(2*pi*i*off); %neg
    inc = inc(:);
  elseif(strcmp(chfld,'xyz-')==1)
    dir = [-1,-1,-1]; dir=dir/norm(dir);
    off = ps(1,:)*dir(1) + ps(2,:)*dir(2) + ps(3,:)*dir(3);
    inc = exp(2*pi*i*off); %neg
    inc = inc(:);
  else
    error('wrong');
  end
  
  if(    strcmp(chchk,'x=0')==1)
    P = sqrt(numel(val));
    tmp = reshape(val,P,P);    tmp = transpose(tmp);    tmp = tmp(end:-1:1,:);    figure; imagesc(real(tmp));
    %figure; trimesh(fs'+1,vs(1,:),vs(2,:),vs(3,:),real(den));
  elseif(strcmp(chchk,'xyz=0')==1)
    P = sqrt(numel(val)/3);
    val1 = val(        [1:P*P]) + inc(        [1:P*P]);
    tmp = reshape(val1,P,P);    tmp = transpose(tmp);    tmp = tmp(end:-1:1,:);    figure; imagesc(real(tmp)); xlabel('y'); ylabel('z'); axis equal;
    val2 = val(  P*P + [1:P*P]) + inc(  P*P + [1:P*P]);
    tmp = reshape(val2,P,P);    tmp = transpose(tmp);    tmp = tmp(end:-1:1,:);    figure; imagesc(real(tmp)); xlabel('z'); ylabel('x'); axis equal;
    val3 = val(2*P*P + [1:P*P]) + inc(2*P*P + [1:P*P]);
    tmp = reshape(val3,P,P);    tmp = transpose(tmp);    tmp = tmp(end:-1:1,:);    figure; imagesc(real(tmp)); xlabel('x'); ylabel('y'); axis equal;
    %figure; trimesh(fs'+1,vs(1,:),vs(2,:),vs(3,:),real(den));
  else
    error('wrong');
  end
end
