#include "kernel3d.hpp"

double Kernel3d::_mindif = 1e-8;
using std::polar;

extern "C"
{
  void vdsqrt_(int* n, double*, double*);
  void vdinv_(int* n, double*, double*);
  void vdsincos_(int* n, double*, double*, double*);
}

//---------------------------------------------------------------------------
int Kernel3d::kernel(const DblNumMat& trgpos, const DblNumMat& srcpos, const DblNumMat& srcnor, CpxNumMat& inter)
{
  int sdof = this->sdof();
  int tdof = this->tdof();
  cpx I(0,1);
  inter.resize(trgpos.n(), srcpos.n());
  //---------------------------
  if(       _type==KNL_HELM_SING) {
    //--
    double K = 2*M_PI;
    int M = trgpos.n();
    int N = srcpos.n();
    double mindif2 = _mindif*_mindif;
    int TTL = M*N;
    DblNumMat rr(M,N);
    for(int i=0; i<M; i++) {
      for(int j=0; j<N; j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);
	double r1 = trgpos(1,i) - srcpos(1,j);
	double r2 = trgpos(2,i) - srcpos(2,j);
	double tmp = r0*r0 + r1*r1 + r2*r2;
	if(tmp>mindif2) {
	  rr(i,j) = tmp;
	} else {
	  rr(i,j) = 1; //LEXING:
	}
      }
    }
    DblNumMat r(M,N);
    vdsqrt_(&TTL, rr.data(), r.data());
    DblNumMat kr(M,N);
    for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
	kr(i,j) = K*r(i,j);
    DblNumMat skr(M,N), ckr(M,N);
    vdsincos_(&TTL, kr.data(), skr.data(), ckr.data());
    //
    double coef = 1/(4*M_PI);
    inter.resize(M,N);
    for(int i=0; i<M; i++) {
      for(int j=0; j<N; j++) {
	inter(i,j) = (coef/r(i,j)) * cpx(ckr(i,j),skr(i,j));
      }
    }
  } else if(_type==KNL_HELM_DOUB) {
    //--
    double K = 2*M_PI;
    for(int i=0; i<trgpos.n(); i++) {
      for(int j=0; j<srcpos.n(); j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);
	double r1 = trgpos(1,i) - srcpos(1,j);
	double r2 = trgpos(2,i) - srcpos(2,j);
	double n0 = srcnor(0,j);
	double n1 = srcnor(1,j);
	double n2 = srcnor(2,j);
	double rr = r0*r0 + r1*r1 + r2*r2;
	double rn = r0*n0 + r1*n1 + r2*n2;
	double r = sqrt(rr);
	double rrr = rr*r;
	if(r<_mindif) {
	  inter(i,j) = 0;
	} else {
	  double Kr = K*r;
	  //inter(i,j) = cpx( cos(Kr)/(4*M_PI*r), sin(Kr)/(4*M_PI*r) );
	  inter(i,j) = 1.0/(4*M_PI) * cpx(cos(Kr),sin(Kr)) * (1.0-I*Kr) / rrr * rn;
	}
      }
    }
  } else if(_type==KNL_HELM_COMB) {
    //--
    double K = 2*M_PI;
    int M = trgpos.n();
    int N = srcpos.n();
    double mindif2 = _mindif*_mindif;
    int TTL = M*N;
    DblNumMat rr(M,N);
    DblNumMat rn(M,N);
    for(int i=0; i<M; i++) {
      for(int j=0; j<N; j++) {
	double r0 = trgpos(0,i) - srcpos(0,j);
	double r1 = trgpos(1,i) - srcpos(1,j);
	double r2 = trgpos(2,i) - srcpos(2,j);
	double n0 = srcnor(0,j);
	double n1 = srcnor(1,j);
	double n2 = srcnor(2,j);
	double tmp = r0*r0 + r1*r1 + r2*r2;
	if(tmp>mindif2) {
	  rr(i,j) = tmp;
	  rn(i,j) = r0*n0 + r1*n1 + r2*n2;
	} else {
	  rr(i,j) = 1; //LEXING:
	  rn(i,j) = 0;
	}
      }
    }
    DblNumMat r(M,N);
    vdsqrt_(&TTL, rr.data(), r.data());
    DblNumMat kr(M,N);
    for(int i=0; i<M; i++)
      for(int j=0; j<N; j++)
	kr(i,j) = K*r(i,j);
    DblNumMat skr(M,N), ckr(M,N);
    vdsincos_(&TTL, kr.data(), skr.data(), ckr.data());
    //
    double eta = 2*M_PI;
    double coef = 1/(4*M_PI);
    inter.resize(M,N);
    for(int i=0; i<M; i++) {
      for(int j=0; j<N; j++) {
	cpx t1 = (coef * (rn(i,j)/(rr(i,j)*r(i,j)))) * cpx(ckr(i,j),skr(i,j)) * cpx(1,-kr(i,j));
	cpx t2 = (coef / r(i,j)) * cpx(ckr(i,j),skr(i,j));
	inter(i,j) = t1 - I*eta*t2;
      }
    }
  } else {
    //--
    iA(0);
  }
  return 0;
}
