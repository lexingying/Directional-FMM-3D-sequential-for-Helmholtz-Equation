#ifndef _VR_HPP_
#define _VR_HPP_

#include "commoninc.hpp"

#include <GL/gl.h>
#include <GL/glu.h>
#include <GL/glut.h>

using std::cerr;
using std::endl;

#define glCheck() __glCheck__(__FILE__, __LINE__)
inline int __glCheck__(const char* fileName, int n) {
  int e = glGetError();
  if (e) cerr<<(char*)gluErrorString(e)<<"  "<<fileName<<", #"<<n<<endl;
  return(e);
}

#endif
